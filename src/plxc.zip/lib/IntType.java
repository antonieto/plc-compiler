package lib;

public class IntType extends Type {
    private static IntType instance;

    private IntType() {}

    public static IntType getInstance() {
        if (instance == null) {
            instance = new IntType();
        }
        return instance;
    }
    @Override
    public boolean isCompatibleWith(Type other) {
        return other instanceof IntType || other instanceof CharType;
    }

    @Override
    public String toString() {
        return "int";
    }

    @Override
    public String addOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return destination + " = " + s1 + " + " + s2 + ";";
    }

    @Override
    public String subsOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return destination + " = " + s1 + " - " + s2 + ";";
    }
    @Override
    public String multOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return destination + " = " + s1 + " * " + s2 + ";";
    }

    @Override
    public String divideOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return destination + " = " + s1 + " / " + s2 + ";";
    }

    @Override
    public String castOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        return destination + " = (int) " + source + ";";
    }

    @Override
    public String printOperation(ExpressionSymbol source) {
        return "print " + source + ";";
    }
}
