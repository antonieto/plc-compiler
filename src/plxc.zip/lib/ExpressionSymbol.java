package lib;

public class ExpressionSymbol {
    private Type type;
    private String name;
    private boolean isMutable;
    public ExpressionSymbol(String name, Type type) {
        this.type = type;
        this.name = name;
    }

    public boolean isCompatibleWith(ExpressionSymbol other) {
        return this.type.isCompatibleWith(other.getType());
    }

    public Type getType() {
        return this.type;
    }

    public void setType(Type t) {
        this.type = t;
    }

    public String getName() {
        return name;
    }

    public boolean isRegister() {
        return this.name.startsWith("$t");
    }

    @Override
    public String toString() {
        return this.name;
    }
}
