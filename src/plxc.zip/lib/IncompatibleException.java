package lib;

public class IncompatibleException extends Exception {
}
