package lib;

public class UndefinedSymbolException extends Exception {
}
