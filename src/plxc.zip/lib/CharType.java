package lib;

import java.util.HashMap;
import java.util.Map;

public class CharType extends Type {

    private static CharType instance;

    private static final Map<Character, Character> escapeMap = new HashMap<>();

    static {
        // Initialize the escape sequence mapping
        escapeMap.put('b', '\b');
        escapeMap.put('t', '\t');
        escapeMap.put('n', '\n');
        escapeMap.put('f', '\f');
        escapeMap.put('r', '\r');
        escapeMap.put('\"', '\"');
        escapeMap.put('\'', '\'');
        escapeMap.put('\\', '\\');
    }
    private CharType() {}

    public static CharType getInstance() {
        if (instance == null) {
            instance = new CharType();
        }
        return instance;
    }

    public static int strToASCII(String str) {
        if (str.length() == 1) {
            // Regular single-character string
            return str.charAt(0);
        } else if (str.length() == 2 && str.charAt(1) != 'u') {
            return escapeMap.get(str.charAt(1));
        } else if (str.startsWith("\\u") && str.length() == 6) {
            // Unicode escape sequence of the form
            try {
                int unicodeValue = Integer.parseInt(str.substring(2), 16);
                return (char) unicodeValue;
            } catch (NumberFormatException e) {
                // Handle the case where parsing fails
                throw new IllegalArgumentException("Invalid Unicode escape sequence: " + str);
            }
        } else {
            // Invalid input
            throw new IllegalArgumentException("Invalid input string: " + str);
        }
    }
    @Override
    public boolean isCompatibleWith(Type other) {
        return other instanceof CharType || other instanceof IntType;
    }

    @Override
    public String toString() {
        return "char";
    }
    @Override
    public String addOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        destination.setType(IntType.getInstance());
        return destination + " = " + s1 + " + " + s2 + ";";
    }

    @Override
    public String subsOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        // Cast type
        destination.setType(IntType.getInstance());
        return destination + " = " + s1 + " - " + s2 + ";";
    }

    @Override
    public String multOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return null;
    }

    @Override
    public String divideOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return null;
    }

    @Override
    public String castOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        // Cast operation is direct
        return destination + " = " + source + ";";
    }

    @Override
    public String assignOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        Type otherType = source.getType();
        if (!(otherType instanceof CharType)) {
            return "error;\nhalt;";
        }
        return super.assignOperation(destination, source);
    }

    @Override
    public String printOperation(ExpressionSymbol source) {
        return "printc " + source + ";";
    }
}
