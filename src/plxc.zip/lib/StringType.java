package lib;

import java.util.HashMap;
import java.util.Map;

// Try as singleton first
public class StringType extends Type {

    private static StringType instance;
    private static final Map<Character, Character> escapeMap = new HashMap<>();

    static {
        // Initialize the escape sequence mapping
        escapeMap.put('b', '\b');
        escapeMap.put('t', '\t');
        escapeMap.put('n', '\n');
        escapeMap.put('f', '\f');
        escapeMap.put('r', '\r');
        escapeMap.put('\"', '\"');
        escapeMap.put('\'', '\'');
        escapeMap.put('\\', '\\');
    }

    public static String convertEscapedCharacters(String str) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < str.length(); i++) {
            char currentChar = str.charAt(i);

            if (currentChar == '\\') {
                // Check if there is an escaped character
                if (i + 1 < str.length()) {
                    char nextChar = str.charAt(i + 1);
                    char convertedChar = getConvertedCharacter(nextChar);

                    // Append the converted character to the result
                    result.append(convertedChar);

                    // Skip the next character as it has been processed
                    i++;
                } else {
                    // If there is a single backslash at the end, treat it as a literal backslash
                    result.append('\\');
                }
            } else {
                // Append non-escaped characters as-is
                result.append(currentChar);
            }
        }

        return result.toString();
    }

    private static char getConvertedCharacter(char escapedChar) {
        // Map escaped characters to their corresponding values
        switch (escapedChar) {
            case 'n': return '\n';
            case 't': return '\t';
            case 'r': return '\r';
            case 'b': return '\b';
            // Add more mappings as needed
            default: return escapedChar; // Treat unknown escapes as literal characters
        }
    }
    public static StringType getInstance() {
        if(instance == null) {
            instance = new StringType();
        }
        return instance;
    }
    private StringType() {}
    // A StringType
    @Override
    public boolean isCompatibleWith(Type other) {
        return other instanceof StringType;
    }

    // TODO: Implement concatenation
    @Override
    public String addOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return null;
    }

    // TODO: Implement this
    @Override
    public String subsOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return null;
    }

    @Override
    public String multOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String divideOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String castOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String printOperation(ExpressionSymbol source) {
        // Implement later
        int c = 0;
        String loopLabel = "L" + source + "$prloop";
        String endLabel = "L" + source + "$pend";
        String tempReg = source + "$reg";
        String countReg = source + "$cnt";
        String result = "";
        // Init tempReg by accessing
        // if ( tempReg == 0 ) goto endLabel;
        result += loopLabel + ":\n";
        result += tempReg + " = " + source + "[" + countReg + "];\n";
        result += "if (" + tempReg + " == 0) goto " + endLabel + ";\n";
        result += "writec " + tempReg + ";\n";
        result += countReg + " = " + countReg + " + 1;\n";
        result += "goto " + loopLabel + ";\n";
        // Print "prints" a line
        result += endLabel + ":\n";
        result += "writec " + (int) '\n' + ";\n";
        result += countReg + " = 0;\n";
        return result;
    }

    @Override
    public String toString() {
        return "string";
    }
}
