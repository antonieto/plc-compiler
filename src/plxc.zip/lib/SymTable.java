package lib;

import java.util.HashMap;
import java.util.Map;

// Table used to keep track of the stored values
public class SymTable {
    private static Map<String, ExpressionSymbol> table = new HashMap<>();
    private SymTable() {}

    public static void add(String name, ExpressionSymbol sym) {
        table.put(name, sym);
    }

    public static boolean has(String name) {
        return table.get(name) != null;
    }

    public static ExpressionSymbol get(String symbol) {
        return table.get(symbol);
    }

    public static void print() {
        System.out.println("<------- Symbol table ------>");
        for (String key: table.keySet()) {
            System.out.println(key + " --- " + table.get(key).getType());
        }
        System.out.println("<------- Symbol table ------>");
    }
}
