package lib;

import java.util.Objects;

// Type is an abstract class, containing
public abstract class Type {
    private static String FLOAT_TYPE_NAME = "float";
    private static String INT_TYPE_NAME = "int";
    private static String CHAR_TYPE_NAME = "char";
    private static String STRING_TYPE_NAME = "string";
    public abstract boolean isCompatibleWith(Type other);

    public static Type getType(String typeName) throws UnsupportedOperationException {
        if (Objects.equals(typeName, FLOAT_TYPE_NAME)) {
            return FloatType.getInstance();
        } else if (Objects.equals(typeName, INT_TYPE_NAME)) {
            return IntType.getInstance();
        } else if (Objects.equals(typeName, CHAR_TYPE_NAME)) {
            return CharType.getInstance();
        } else if (Objects.equals(typeName, STRING_TYPE_NAME)) {
            return StringType.getInstance();
        }
        throw new UnsupportedOperationException("Unsupported type " + typeName);
    }

    public abstract String addOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2);
    public abstract String subsOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2);
    public abstract String multOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) throws Exception;
    public abstract String divideOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2);

    public abstract String castOperation(ExpressionSymbol destination, ExpressionSymbol source);

    // To overridden as required
    public String assignOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        return destination + " = " + source + ";";
    };

    public ExpressionSymbol attributeAccess(ExpressionSymbol source, String attribute) {
        throw new UnsupportedOperationException();
    }
    public abstract String printOperation(ExpressionSymbol source);
    public abstract String toString();
}

