package lib;

// yes it's a singleton yes it's an antipattern
public class FloatType extends Type {

    private static FloatType instance;
    private FloatType() {}

    public static FloatType getInstance() {
        if (instance == null) {
            instance = new FloatType();
        }
        return instance;
    }

    @Override
    public boolean isCompatibleWith(Type other) {
        return other instanceof FloatType || other instanceof IntType;
    }

    @Override
    public String toString() {
        return "float";
    }

    @Override
    public String addOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return destination + " = " + s1 + " +r " + s2 + ";";
    }

    @Override
    public String subsOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return destination + " = " + s1 + " -r " + s2 + ";";
    }
    @Override
    public String multOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return destination + " = " + s1 + " *r " + s2 + ";";
    }

    @Override
    public String divideOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return destination + " = " + s1 + " /r " + s2 + ";";
    }

    @Override
    public String castOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        return destination + " = (float) " + source + ";";
    }

    @Override
    public String printOperation(ExpressionSymbol source) {
        return "print " + source + ";";
    }

}
