
package lib;

import java.io.PrintStream;

public class GlobalRepository {
    public static Type typeBuffer = null;
    private static PrintStream out = System.out;
    public static void setOut(PrintStream newOut) {
        out = newOut;
    }
    private static int varCount = 0;
    public static String newVar() {
        String var = "$t" + varCount;
        varCount++;
        return var;
    }

    private static int labelCount = 0;
    public static String newLabel() {
        String label = "L" + labelCount;
        labelCount++;
        return label;
    }
}
