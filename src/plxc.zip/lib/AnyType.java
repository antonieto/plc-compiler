package lib;

public class AnyType extends Type {
    @Override
    public boolean isCompatibleWith(Type other) {
        return true;
    }

    @Override
    public String addOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return "";
    }

    @Override
    public String subsOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return "";
    }

    @Override
    public String multOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) throws Exception {
        return "";
    }

    @Override
    public String divideOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return "";
    }

    @Override
    public String castOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        return "";
    }

    @Override
    public String printOperation(ExpressionSymbol source) {
        return "";
    }

    @Override
    public String toString() {
        return "any";
    }
}
