package lib;

import java.util.List;

// Util data class for list declaration
public class ExpressionList {

    private final List<ExpressionSymbol> symbols;
    private final Type type;

    public ExpressionList(List<ExpressionSymbol> symbols, Type type) throws IncompatibleException {
        for (ExpressionSymbol symbol: symbols) {
            if (symbol.getType() != type) {
                throw new IncompatibleException();
            }
        }
        this.symbols = symbols;
        this.type = type;
    }

    public void add(ExpressionSymbol sym) throws IncompatibleException {
        if(sym.getType() != this.type) {
            throw new IncompatibleException();
        }
        this.symbols.add(sym);
    }

    public List<ExpressionSymbol> getSymbols() {
        return this.symbols;
    }

    public Type getType() {
        return this.type;
    }
}
