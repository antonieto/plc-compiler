package lib;

public class ArrayType extends Type {

    // This won't be a singleton, there can be many instances of an ArrayType: ArrayType<Int, Length>
    private final int size;
    private final Type contentType;

    public int getSize() {
        return this.size;
    }

    public Type getContentType() {
        return this.contentType;
    }

    public ArrayType(Type contentType, int size) {
        this.contentType = contentType;
        this.size = size;
    }

    @Override
    public boolean isCompatibleWith(Type other) {
        if (!(other instanceof ArrayType)) {
            return false;
        }
        ArrayType otherType = (ArrayType) other;
        if (this.contentType instanceof ArrayType) {
            return this.contentType.isCompatibleWith(otherType.getContentType());
        }
        return this.contentType == otherType.getContentType();
    }

    @Override
    public String addOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return "error;\nhalt;";
    }

    @Override
    public String subsOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return "error;\nhalt;";
    }

    @Override
    public String multOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return "error;\nhalt;";
    }

    @Override
    public String divideOperation(ExpressionSymbol destination, ExpressionSymbol s1, ExpressionSymbol s2) {
        return "error;\nhalt;";
    }

    @Override
    public String castOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        return "error;\nhalt;";
    }

    @Override
    public String assignOperation(ExpressionSymbol destination, ExpressionSymbol source) {
        String continueLabel = GlobalRepository.newLabel();
        StringBuffer resultBuffer = new StringBuffer();
        resultBuffer.append("if (" + source + "$SIZE == " + destination + "$SIZE) goto " + continueLabel + ";\n");
        resultBuffer.append("if (" + source + "$SIZE < " + destination + "$SIZE) goto " + continueLabel + ";\n");
        resultBuffer.append("error;\n");
        resultBuffer.append("halt;\n");
        resultBuffer.append(continueLabel + ":\n");
        // Copy elements
        String loopLabel = GlobalRepository.newLabel();
        String endLabel = GlobalRepository.newLabel();
        String countReg = GlobalRepository.newVar();
        String tempReg = GlobalRepository.newVar();
        resultBuffer.append(countReg + " = 0;\n");
        resultBuffer.append(loopLabel + ":\n");
        resultBuffer.append("if (" + source + "$SIZE" + " == " + countReg + ") goto " + endLabel + ";\n");
        resultBuffer.append("if (" + source + "$SIZE" + "< " + countReg + ") goto " + endLabel + ";\n");
        resultBuffer.append(tempReg + " = " + source + "[" + countReg + "];\n");
        // Copy element
        resultBuffer.append(destination + "[" + countReg + "] = " + tempReg + ";\n");
        resultBuffer.append(countReg + " = " + countReg + " + 1;\n");
        resultBuffer.append("goto " + loopLabel + ";");
        resultBuffer.append(endLabel + ":");
        resultBuffer.append("");
        return resultBuffer.toString();
    }

    @Override
    public String printOperation(ExpressionSymbol source) {
        // Create a loop and print the array
        String loopLabel = GlobalRepository.newLabel();
        String endLabel = GlobalRepository.newLabel();
        String countReg = GlobalRepository.newVar();
        String tempReg = GlobalRepository.newVar();
        StringBuffer resultBuffer = new StringBuffer();

        resultBuffer.append(countReg + " = 0;\n");
        resultBuffer.append(loopLabel + ":\n");
        resultBuffer.append("if (" + source + "$SIZE" + " == " + countReg + ") goto " + endLabel + ";\n");
        resultBuffer.append("if (" + source + "$SIZE" + "< " + countReg + ") goto " + endLabel + ";\n");
        resultBuffer.append(tempReg + " = " + source + "[" + countReg + "];\n");
        resultBuffer.append(this.contentType.printOperation(new ExpressionSymbol(tempReg, this.contentType)));
        resultBuffer.append(countReg + " = " + countReg + " + 1;\n");
        resultBuffer.append("goto " + loopLabel + ";");
        resultBuffer.append(endLabel + ":");
        return resultBuffer.toString();
    }

    @Override
    public ExpressionSymbol attributeAccess(ExpressionSymbol source, String attribute) {
        if (!(source.getType() instanceof ArrayType)) {
            throw new UnsupportedOperationException();
        }
        // Return
        switch(attribute) {
            case "length":
                return new ExpressionSymbol(source.toString() + "$SIZE", IntType.getInstance());
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override
    public String toString() {
        return "Array<" + this.contentType + ">";
    }
}
